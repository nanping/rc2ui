App({
  onLaunch: function () {
    console.log('App Launch')
    wx.cloud.init({
      env:'shopdatabase-6gcqhy3pb7379edd'//xxx填写云开发环境id
  })


  },
  onShow: function () {
    console.log('App Show')
  },
  onHide: function () {
    console.log('App Hide')
  },
  onShareAppMessage: function () {
    return {
      title: 'XX超市',
      desc: 'XX超市，方便大家',
      path: "page/index",
    }
  },
  globalData: {
    hasLogin: false,
    IsAdministrator:false,
    CurrentProductID:""
  }
})
