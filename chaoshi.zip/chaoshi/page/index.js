Page({
  data: {
    code:'',
    useropenid:'000',
    
    msg:'初始化数据',
    userInfo:{}, // 用户基本信息
    canIUseGetUserProfile: true,
    phone:'13212341234',
    imgUrls: [
      '/image/aa1.jpg',
      '/image/aa2.jpg'
    
    ],
	noticeIdx: 0,
    notices: [
      {
         "info": "欢迎各位朋友光临本店"
      },
      {
        "info": "XX超市欢迎您！"
      },
      {
         "info": "主营：文化用品，日用百合，烟酒批发。"
      }
    ],
    indicatorDots: false,
    autoplay: false,
    interval: 3000,
    duration: 800,
  },
  onLoad: function() {

  
// ————————————————
// 版权声明：本文为CSDN博主「小绵杨Yancy」的原创文章，遵循CC 4.0 BY-SA版权协议，转载请附上原文出处链接及本声明。
// 原文链接：https://blog.csdn.net/ZHANGYANG_1109/article/details/118383498
 

  
    var me = this;
    var animation = wx.createAnimation( {
      duration: 400,
      timingFunction: 'ease-out',
    });
    me.animation = animation;
    wx.getSystemInfo( {
      success: function( res ) {
        me.setData( { windowWidth: res.windowWidth })
      }
    });

    console.log( 'onLoad' );
  },

  // async getPhoneNumber(res) {
  //   console.log(res)
  //   const errMsg = res.detail.errMsg
  //   if (errMsg != "getPhoneNumber:ok"){
  //     //个人号申请的微信小程序开发，无法微信认证，因此授权失败，拿不到手机号
  //     wx.showToast({
  //       title: '授权失败',
  //       icon: 'error'
  //     })
  //     return
  //   }
  //   const cloudId = res.detail.cloudID
  //   const cloudIdList = [cloudId]
  //   wx.showLoading({
  //     title: '获取中',
  //     mask: true
  //   })
  //   const cloudFunRes = await wx.cloud.callFunction({
  //     name: "getPhoneNumber",
  //     data: {
  //       cloudIdList
  //     }
  //   })
  //   console.log("cloudFunRes: ",cloudFunRes)
  //   const jsonStr = cloudFunRes.result.dataList[0].json
  //   const jsonData = JSON.parse(jsonStr)
  //   const phoneNumber = jsonData.data.phoneNumber
  //   console.log(phoneNumber)
  //   this.setData({
  //     userPhone: phoneNumber
  //   })
  //   wx.hideLoading({
  //     success: (res) => {},
  //   })
  // },

//   getPhoneNumber: function (e) {

//     console.log(e.detail.errMsg)
//     //授权后的处理
//     if (e.detail.errMsg == "getPhoneNumber:ok") {
//         //用户信息
//         let params = {
//             encrypdata:e.detail.encryptedData,
//             ivdata: e.detail.iv,
//             sessionkey:this.data.userInfo.sessionKey
//         }
//         console.log('参数', params)
//         //后端获取参数进行解密
//         Api.getPhoneNumber(params).then(datas => {
//             console.log('手机号码',res)

//         })
//     }
// },

// ————————————————
// 版权声明：本文为CSDN博主「高级BUG制造者」的原创文章，遵循CC 4.0 BY-SA版权协议，转载请附上原文出处链接及本声明。
// 原文链接：https://blog.csdn.net/weixin_45762805/article/details/104904713

  getInfo(){

    var me = this;

    wx.login({
      success(res) {
       if (res.errMsg == 'login:ok') {
        console.log(res.code);
        me.setData({
           code : res.code
          });
         //this.data.code=res.code;
         console.log(me.data.code);		// 获取到当前code 有了code之后，才能够进行获取当前的openid
         // 进行获取openid
          wx.request({
               url: 'https://api.weixin.qq.com/sns/jscode2session?appid=' + 'wx14151ded7b4b6928' + '&secret=' + '629c49bd4032a59741713142d271ded6' + '&js_code=' + res.code + '&grant_type=authorization_code',
               data: {},
               // header: {
               //   'content-type': 'json'
               // },
               success: function (res) {
                 var openid = res.data.openid //返回openid
                 console.log('openid ===> ' + openid);
                 //wx.setStorageSync('od', openid)
               }
             })
         }
      }






    });
  },
    // ————————————————
    // 版权声明：本文为CSDN博主「H-rosy」的原创文章，遵循CC 4.0 BY-SA版权协议，转载请附上原文出处链接及本声明。
    // 原文链接：https://blog.csdn.net/qq_51580852/article/details/126860681

    getUserOpenID(){
      var that=this;
      wx.cloud.callFunction({
        name:'getUserPhoneNumber',
        data:{
          message:'hellocloud',
        }
      }).then(res=>{
        console.log(res)//res就将appid和openid返回了
          //做一些后续操作，不用考虑代码的异步执行问题。
          that.setData({
            useropenid:res.result.OPENID           
          })

          getApp().globalData.IsAdministrator=res.result.IsAdministrator;
          console.log("IsAdministrator: ",getApp().globalData.IsAdministrator);


        })
    // ————————————————
    // 版权声明：本文为CSDN博主「mir frog」的原创文章，遵循CC 4.0 BY-SA版权协议，转载请附上原文出处链接及本声明。
    // 原文链接：https://blog.csdn.net/m0_58609505/article/details/127318360

    },





  //获取手机号
  async getUserOpenID2(){
    
    wx.cloud.init({
      env:'shopdatabase-6gcqhy3pb7379edd'//xxx填写云开发环境id
    })
    const db = wx.cloud.database()

    wx.getUserProfile({
      desc: '用于获取用户个人信息',
      success: function (detail) {
        console.log(detail)
        console.log("encryptedData "+detail.encryptedData)
        console.log("nickName  "+detail.userInfo.nickName)

        wx.login({
          success: res => {
            var code = res.code; //登录凭证
            wx.cloud.callFunction({
              name: "getUserPhoneNumber",
              data: {
                encryptedData: detail.encryptedData,
                iv: detail.iv,
                code: code,
                userInfo: detail.rawData
              }
            }).then(res => {
              console.log("res: ",res);
              var openid = res.result.openid;
              //var status = res.result.status;
              var phone = res.result.CurrentPhone;
              console.log("openid: ",openid);
              //console.log("status: ",status);
              console.log("phone: ",phone);
              console.log("nickName: ",detail.userInfo.nickName);
              
              // if(phone==undefined){
              //   console.log("需要绑定手机号");
              // }else{
              //   console.log("授权成功");
              // }

            }).catch(res => {
              console.log("res3: ",res);
            })
          }
        });

      },
      fail: function () {
        wx.showModal({
          content: '取消授权将会影响相关服务，您确定取消授权吗？',
          success (res) {
            if (res.confirm) {
              wx.showToast({
                title: '已取消授权',
                duration: 1500
              })
            } else if (res.cancel) {
              //this.getUserProfile()
            }
          }
        })
      }
    })
    


        
  },
   
// ————————————————
// 版权声明：本文为CSDN博主「Suifqwu」的原创文章，遵循CC 4.0 BY-SA版权协议，转载请附上原文出处链接及本声明。
// 原文链接：https://blog.csdn.net/qq_41399894/article/details/124940088




  startNotice: function() {
    var me = this;
    var notices = me.data.notices || [];
    if( notices.length == 0 ) {
      return;
    }

    var animation = me.animation;
    //animation.translateY( -12 ).opacity( 0 ).step();
    animation.translateY( 0 ).opacity( 1 ).step( { duration: 0 });
    me.setData( { animationNotice: animation.export() });

    var noticeIdx = me.data.noticeIdx + 1;
    if( noticeIdx == notices.length ) {
      noticeIdx = 0;
    }

    // 更换数据
    setTimeout( function() {
      me.setData( {
        noticeIdx: noticeIdx
      });
    }, 400 );

    // 启动下一次动画
    setTimeout( function() {
      me.startNotice();
    }, 5000 );
  },
  onShow: function() {
    this.startNotice();

  },
    onShareAppMessage: function () {
    return {
      title: 'XX超市',
      desc: '文化用品，日用百合，烟酒批发。',
      path: "page/index",
    }
  },
})