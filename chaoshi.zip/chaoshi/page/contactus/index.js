// page/new-pages/user/user.js
Page({
  data:{
    latitude: 23.049382,
    longitude: 113.727904,
	covers: [{
    latitude: 23.049382,
    longitude: 113.727904,
    }],
	markers: [{
    latitude: 23.049382,
    longitude: 113.727904,

    }],
	accuracy: 16,
    thumb:'',
    nickname:'',
   
    hasAddress:false,
    address:{}
  },
  onLoad(){
    var that = this;
    this.getmylocation();
  },
  onShow(){
    console.log("... show...");
  },
  //http://lbs.qq.com/tool/getpoint/ 坐标拾取器
  click: function (e) {
    wx.openLocation({
      latitude: 23.049382,
      longitude: 113.727904,
      scale: 18,
      name: '超市',
      address: ''
    })
  },
  teltoUs:function(){

	   wx.makePhoneCall({
       phoneNumber: '15985x3003' //仅为示例，并非真实的电话号码
		})
   },
  teltoUs1: function () {
    wx.makePhoneCall({
      phoneNumber: '15985xx3093' //仅为示例，并非真实的电话号码
    })
  },
  teltoUs2: function () {
    wx.makePhoneCall({
      phoneNumber: '15985xx090' //仅为示例，并非真实的电话号码
    })
  },
  onShareAppMessage: function () {
    return {
   
      title: 'XX超市',
      desc: 'XX超市，人民的超市',
        path: "page/index",
      
    }
  }	,
  getmylocation: function(){
    console.log("... get location...");

    wx.getLocation({
      altitude: true,
      highAccuracyExpireTime: 0,
      isHighAccuracy: true,
      type: 'gcj02',
      success: (result) => {
        console.log( result.longitude + "," + result.latitude );
    },
      fail: (res) => {console.log("fail get location")},
      complete: (res) => {
        console.log( res.longitude + "," + res.latitude );
    },
    })
  }


})