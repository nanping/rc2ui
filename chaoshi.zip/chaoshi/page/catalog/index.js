// page/index.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
      IsAdministrator:Boolean,
      status:'mEI DENG lu',
      producttype:[],
      currenttype:Number,
      productlist:[], 
      showproductlist:[],      
      viewId:[]
  },
 

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {

    this.data.currenttype=1;

    wx.cloud.database().collection('Product')  //固定写法
      .where({typeid:this.data.currenttype})
      .get()
      .then(res=>{
          console.log('Product请求成功',res)
          // this.setData({
          //     showproductlist:res.data              
          // })

          this.setData({
            productlist:res.data              
        })

      })
      .catch(err=>{
          console.log('请求失败',err)
      })

      wx.cloud.database().collection('ProductType')  //固定写法
      .get()
      .then(res=>{
          console.log('ProductType请求成功',res)
          this.setData({
            producttype:res.data          
          })
          
      })
      .catch(err=>{
          console.log('请求失败',err)
      })

  
      



  },

  fileImport() {
    const _this = this
    wx.chooseMessageFile({ // 使用微信的方法进入聊天界面选择你之前接受过的文件
      count: 1, // 最多可以选择的文件个数，可以 0～100
      type: 'image', // 所选的文件的类型，其它属性可以看官方文档
      success(res) {
       
        const tempFilePaths = res.tempFiles
        for(let i=0; i < tempFilePaths.length; i++){//多个图片的循环上传
          console.log(tempFilePaths[i].name)
          console.log(tempFilePaths[i].size)
        }

        // const fs = wx.getFileSystemManager() // 再调用一下微信的文件管理器，里面很多方法，但这里的需求是获取文件内容，所以我这里用readFile方法
     
      },
      fail(error) {
        console.log("选择文件失败", error)
      }
    })
  },
  switchToUpload(){
    var app = getApp();
    app.globalData.CurrentProductID="D-1-1";
    wx.navigateTo({
      url: '/page/ManageList/ManageList'
    })

  },

  upload(){
    let that=this;
    let finished = {url:[]}  //本次上次成功的URL存入这个变量,被success方法的e.detail承接

    wx.chooseImage({//异步方法
      count: 1,//最多选择图片数量
      sizeType:['original', 'compressed'],//选择的图片尺寸 原图，压缩图
      sourceType:['album','camera'],//相册选图，相机拍照
      success(res){
        //tempFilePaths可以作为图片标签src属性
        const tempFilePaths = res.tempFilePaths

         //console.log("选择成功",res)
         console.log(res.tempFilePaths[0].path)
        //  console.log(res.height+","+res.width)

         for(let i=0; i < tempFilePaths.length; i++){//多个图片的循环上传
          let filePath = tempFilePaths[i]  //原名
          let cloudPath = 'Chao_Shi/' + filePath.match(/\.[^.]+?$/)[0]  //云存储文件名
          console.log("filePath ",filePath)
          console.log("cloudPath ",cloudPath)

          // wx.cloud.uploadFile({//上传至微信云存储
          //   // cloudPath:'Chao_Shi/' + new Date().getTime() + "_" +  Math.floor(Math.random()*1000) + ".jpg",//使用时间戳加随机数作为上传至云端的图片名称
          //   cloudPath,
          //   filePath:tempFilePaths[i],// 本地文件路径
          //   success: res => {
          //     // 返回文件 ID
          //     console.log("上传成功",res.fileID)

          //     finished.url.push({url:res.fileID})     //成功一个存一个到本次上传成功列表
          //     // that.setData({
          //     //   images:res.fileID//获取上传云端的图片在页面上显示
          //     // })

          //     wx.showToast({
          //       title: '上传成功',
          //     })
          //   }
          // })


        }
 
      }
    })
  },


  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {
  

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {
      console.log("show");

      this.setData({
        IsAdministrator:getApp().globalData.IsAdministrator,
      })

      if(this.data.IsAdministrator){
        this.setData({
          status:"DengLu",
        })     

      }else{

        this.setData({
          status:"Mei DengLu",
        }) 
      }

      // const pages = getCurrentPages()
      // const perpage = pages[pages.length - 1]
      // perpage.onLoad()

  

	    
  },
  fetchData:function(){
    this.data.IsAdministrator=getApp().globalData.IsAdministrator;
    console.log("fetchData IsAdministrator: ",this.data.IsAdministrator);
  },
  showItem: function(event) {
        var that=this;
        var index1=event.currentTarget.dataset.id;
        this.data.currenttype=index1;
        console.log(index1);
 
        that.setData({showproductlist :
           this.data.productlist.filter(function (product) 
           {    
             return product.typeid==index1;
            })}
        );

        console.log(this.data.showproductlist);
        
        // let datas = this.data.productlist;
        // for (var index in datas) {
        //   if(datas[index].typeid==event.currentTarget.dataset.id){
        //     console.log(index + ' 名：' + datas[index].name + ' ：' + datas[index].id);
        //     var viewId = datas[index].id;
        //     that.setData({
        //       viewId: viewId
        //     });
        //     console.log(viewId);

        //   }
        // }
   

      },

       showDetail: function(event) {
        var that=this;
        var viewId = "D-" + event.currentTarget.dataset.id + "-" + event.currentTarget.dataset.id+"00";
        
        that.setData({
          viewId: viewId
         });
        console.log(viewId);
       },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})