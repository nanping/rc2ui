// 云函数入口文件
const cloud = require('wx-server-sdk')
cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV }) // 使用当前云环境

const db = cloud.database()

var rp = require('request-promise');

// 云函数入口函数

let user_uid;
let myuser_id;

// 云函数入口函数
exports.main = async (event, context) => {

  let { APPID,OPENID}=cloud.getWXContext()
  myuser_id=OPENID;
  var Info="OPENID ";
  var IsAdministrator=false;
  let UserCount = 0;
  
   if (OPENID!=''){
      Info="Go to database "+OPENID;
      await
      db.collection('Account').where({
        user_id: OPENID // 填入当前用户 openid
      }).count().then(async res => {    //加异步关键字
        UserCount = res.total;
        Info="UserCount "+UserCount;
        if(UserCount == 0){/* 插入当前列表 */
          await db.collection('Account').add({
            data: {
              user_id: OPENID,
              // nickName: userInfo.nickName,
              // avatarUrl: userInfo.avatarUrl,
              // gender: userInfo.gender,
              // phone: ''
            }
          })
          .then(async res => {
            //resolve("Insert success!");
            Info=Info + " Insert success!";
          })
          .catch(res => {
            //reject("Insert fail!");
            Info=Info + " Insert fail!";
          })
        }else if(UserCount == 1){/* 更新当前列表 */

          await db.collection('Account').where({
            user_id: OPENID // 填入当前用户 openid
          }).get() 
          .then(async res=>{
            console.log('请求成功',res)
            IsAdministrator=res.data[0].IsAdministrator
            Info=Info + " IsAdministrator "+IsAdministrator;    
        })
        .catch(err=>{
            console.log('请求失败',err)
            Info=Info + ' 请求失败'
        })

          await db.collection('Account').where({
            user_id: OPENID // 填入当前用户 openid
          }).update({
            data: {
              // nickName: userInfo.nickName,
              // avatarUrl: userInfo.avatarUrl,
              // gender: userInfo.gender,
              phone:"153"
            }
          })
          .then(async res => {
            //resolve("Update success!");
            Info=Info +" Update success!";
          }).catch(res => {
            //reject("Update fail!");
            Info=Info +" Update fail!";
          })

          
          






        }else if(UserCount > 1){/* 删除所有此id的并且重新添加 */
          await db.collection('Account').where({
            user_id: OPENID // 填入当前用户 openid
          }).remove()
          .then(async res => {
            db.collection('Account').add({
              data: {
                user_id: OPENID,
                // 'nickName': userInfo.nickName,
                // 'avatarUrl': userInfo.avatarUrl,
                // 'gender': userInfo.gender,
                // 'phone': ''
              }
            })
            //resolve("Remove and insert success!");
            Info=Info +" Remove and insert success!";

          }).catch(res => {
            //reject("Remove fail!");
            Info=Info +" Remove fail!";
          })
        }
      }).catch(res => {
        //reject("Query fail!");
        Info="Query fail!";
      })

      
      return {
        APPID,
        OPENID,
        IsAdministrator,
        Info
      }


    }else{
      Info="ID ?";
      return {
        APPID,
        OPENID,
        IsAdministrator,
        Info
      }
    }

    // const CurrentPhoneObject = await db.collection('Account').where({
    // user_id: user_id // 填入当前用户 openid
    // }).get()
    // const CurrentPhone = CurrentPhoneObject.data[0].phone
    // console.log("CurrentPhone: ",CurrentPhone);
    // console.log("stat: ",stat);
    // console.log("user_id: ",user_id);
    // console.log("user_uid: ",user_uid);



   
  
  
  
  }





// exports.main = async (event, context) => {
//   const wxContext = cloud.getWXContext()
//   let code = event.code;//获取小程序传来的code
//   let encryptedData = event.encryptedData;//获取小程序传来的encryptedData
//   let iv = event.iv;//获取小程序传来的iv


//   let userInfo = JSON.parse(event.userInfo) //获取个人信息
//   let appid = "wx14151ded7b4b6928";//自己小程序后台管理的appid，可登录小程序后台查看
//   let secret = "629c49bd4032a59741713142d271ded6";//小程序后台管理的secret，可登录小程序后台查看
//   let grant_type = "authorization_code";// 授权（必填）默认值
//   let url = 'https://api.weixin.qq.com/sns/jscode2session?grant_type='+grant_type+'&appid='+appid+'&secret='+secret+'&js_code='+code;

//   var MyPhone="123";
//   var InError="";

// //   rp({
// //     url:url,     //'服务器后端接口'
// //     data:{
// //        'encryptedData':event.encryptedData,
// //        'iv':event.iv,
// //        'codes':event.code
// //     },
// //     method:'GET',
// //     header:{
// //         'content-type':'application/json'
// //     },
// //     success:function(res){
// //         //wx.setStorageSync('PhoneNumber',res.data.phoneNumber);
// //         console.log("手机号为" + res.data.phoneNumber);
// //         user_id = res.data.openid;
// //         //MyPhone=res.data.phoneNumber;
// //         MyPhone="15312345678";
// //     },
// //     fail:function(err){
// //         console.log(err);
// //         MyPhone="eee";
// //     }
// // })

// // ————————————————
// // 版权声明：本文为CSDN博主「程序小菜鸟·」的原创文章，遵循CC 4.0 BY-SA版权协议，转载请附上原文出处链接及本声明。
// // 原文链接：https://blog.csdn.net/aaa123aaasqw/article/details/130708531




//     const stat = await new Promise((resolve, reject) => {
//       rp(url, (err, response, body) => {
//         if (!err && response.statusCode == 200) {
//           let _data = JSON.parse(body)
//           let UserCount = 0;
//           user_id = _data.openid
//           user_uid = _data.unionid

//           // var msg = err.detail.errMsg;
//           // var sessionKey = _data.session_key;//会话密钥
//           // var encryptedData=err.detail.encryptedData; //签名
//           // var iv= err.detail.iv;                  //授权成功

//           // if (msg == 'getPhoneNumber:ok') {
//           //   wx.checkSession({
//           //     success:function(){                        //进行请求服务端解密手机号
//           //         //this.deciyption(sessionKey,encryptedData,iv,unionid);
//           //     }
//           //   })
//           // }



//           console.log("user_id "+user_id)
//           console.log("user_uid "+user_uid)

          

//         }else{
//             InError=err;
//         }



//       })


//     })

//     if (user_id!=''){
//       db.collection('Account').where({
//         user_id: _data.openid // 填入当前用户 openid
//       }).count().then(res => {
//         UserCount = res.total;
//         if(UserCount == 0){/* 插入当前列表 */
//           db.collection('Account').add({
//             data: {
//               user_id: _data.openid,
//               nickName: userInfo.nickName,
//               avatarUrl: userInfo.avatarUrl,
//               gender: userInfo.gender,
//               phone: ''
//             }
//           })
//           .then(res => {
//             resolve("Insert success!");
//           })
//           .catch(res => {
//             reject("Insert fail!");
//           })
//         }else if(UserCount == 1){/* 更新当前列表 */
//           db.collection('Account').where({
//             user_id: _data.openid // 填入当前用户 openid
//           }).update({
//             data: {
//               nickName: userInfo.nickName,
//               avatarUrl: userInfo.avatarUrl,
//               gender: userInfo.gender
//             }
//           })
//           .then(res => {
//             resolve("Update success!");
//           }).catch(res => {
//             reject("Update fail!");
//           })
//         }else if(UserCount > 1){/* 删除所有此id的并且重新添加 */
//           db.collection('Account').where({
//             user_id: _data.openid // 填入当前用户 openid
//           }).remove()
//           .then(res => {
//             db.collection('Account').add({
//               data: {
//                 user_id: _data.openid,
//                 nickName: userInfo.nickName,
//                 avatarUrl: userInfo.avatarUrl,
//                 gender: userInfo.gender,
//                 phone: ''
//               }
//             })
//             resolve("Remove and insert success!");
//           }).catch(res => {
//             reject("Remove fail!");
//           })
//         }
//       })

//     }

//     // const CurrentPhoneObject = await db.collection('Account').where({
//     // user_id: user_id // 填入当前用户 openid
//     // }).get()
//     // const CurrentPhone = CurrentPhoneObject.data[0].phone
//     // console.log("CurrentPhone: ",CurrentPhone);
//     // console.log("stat: ",stat);
//     // console.log("user_id: ",user_id);
//     // console.log("user_uid: ",user_uid);

  

//   return {
//     //status: stat,
//     CurrentPhone: MyPhone,
//     openid: user_id,
//     unionid: user_uid,
//     error:InError
//   }
// }
// ————————————————
// 版权声明：本文为CSDN博主「Suifqwu」的原创文章，遵循CC 4.0 BY-SA版权协议，转载请附上原文出处链接及本声明。
// 原文链接：https://blog.csdn.net/qq_41399894/article/details/124940088



// const cloud = require('wx-server-sdk')
 
// cloud.init({
//   env: cloud.DYNAMIC_CURRENT_ENV
// })
 
// // 云函数入口函数
// exports.main = async (event) => {
//   const wxContext = cloud.getWXContext()
//   const openid = wxContext.OPENID
//   const appid = wxContext.APPID
//   const unionid = wxContext.UNIONID
//   const enc = wxContext.ENV
//   const cloudIdList = event.cloudIdList
//   try {
//     const result = await cloud.openapi.cloudbase.getOpenData({
//       openid: openid,
//       cloudidList: cloudIdList
//     })
    
//     const jsonStr = result.dataList[0].json
//     const jsonData = JSON.parse(jsonStr)
//     const phoneNumber = jsonData.data.phoneNumber
//     console.log("phoneNumber: ",phoneNumber)
 
//     return result
//   } catch (err) {
//     return err
//   }
// }
// ————————————————
// 版权声明：本文为CSDN博主「Suifqwu」的原创文章，遵循CC 4.0 BY-SA版权协议，转载请附上原文出处链接及本声明。
// 原文链接：https://blog.csdn.net/qq_41399894/article/details/124940088